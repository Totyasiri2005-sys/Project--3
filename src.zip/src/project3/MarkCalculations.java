package project3;

public interface MarkCalculations {
    double calculateAverage();
    double findMax();
    double findMin();
    boolean isPass();
}